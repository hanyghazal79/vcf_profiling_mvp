"""
Simple FastAPI server for online analysis mode
"""

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from typing import Optional
import tempfile
from pathlib import Path

from genetic_analyzer import analyze_vcf_api, GeneticAnalyzer

app = FastAPI(
    title="Breast Cancer Genetic Risk API",
    description="API for analyzing VCF files for breast cancer risk variants",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to your Flutter app domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Breast Cancer Genetic Risk Assessment API"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": "genetic-risk-api"}

@app.post("/api/analyze")
async def analyze_vcf(
    file: UploadFile = File(...),
    patient_id: Optional[str] = "P001",
    mode: Optional[str] = "offline"
):
    """
    Analyze VCF file for breast cancer risk variants
    
    Args:
        file: VCF file upload
        patient_id: Optional patient identifier
        mode: Analysis mode - 'offline' or 'online'
    
    Returns:
        Analysis results in JSON format
    """
    try:
        # Validate file type
        if not file.filename.endswith(('.vcf', '.vcf.gz')):
            raise HTTPException(status_code=400, detail="File must be a VCF file")
        
        # Read file content
        content = await file.read()
        vcf_content = content.decode('utf-8')
        
        # Validate minimum VCF content
        if "#CHROM" not in vcf_content:
            raise HTTPException(status_code=400, detail="Invalid VCF file format")
        
        # Analyze VCF
        results = analyze_vcf_api(vcf_content, patient_id, mode)
        
        return JSONResponse(content=results)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.post("/api/analyze-local")
async def analyze_local_vcf(
    file_path: str,
    patient_id: Optional[str] = "P001",
    mode: Optional[str] = "offline"
):
    """
    Analyze VCF file from local path (for testing/demo)
    """
    try:
        # Check if file exists
        if not Path(file_path).exists():
            raise HTTPException(status_code=404, detail="File not found")
        
        # Read file
        with open(file_path, 'r') as f:
            vcf_content = f.read()
        
        # Analyze
        results = analyze_vcf_api(vcf_content, patient_id, mode)
        
        return JSONResponse(content=results)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.get("/api/demo-results")
async def get_demo_results():
    """Get demo results for testing UI"""
    try:
        # Create analyzer and generate demo results
        analyzer = GeneticAnalyzer(mode='offline')
        results = analyzer.process_vcf("demo.vcf", "DEMO001")
        
        return JSONResponse(content=results)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate demo: {str(e)}")

if __name__ == "__main__":
    # Run server
    uvicorn.run(
        "api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )