"""
Report generator for creating visualizations and formatted output
"""

import json
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List

class ReportGenerator:
    """Generate visualizations and formatted reports from analysis results"""
    
    @staticmethod
    def create_risk_distribution_plot(results: Dict, save_path: str = None):
        """Create pie chart of risk distribution"""
        plots_data = results.get('plots', {})
        risk_data = plots_data.get('risk_distribution', {})
        
        if not risk_data:
            return None
        
        # Create pie chart
        labels = list(risk_data.keys())
        values = list(risk_data.values())
        
        fig = go.Figure(data=[go.Pie(
            labels=labels,
            values=values,
            hole=.3,
            marker_colors=['#FF6B6B', '#FFD166', '#06D6A0']
        )])
        
        fig.update_layout(
            title="Variant Risk Distribution",
            showlegend=True
        )
        
        if save_path:
            fig.write_html(save_path)
        
        return fig.to_dict()
    
    @staticmethod
    def create_gene_distribution_chart(results: Dict, save_path: str = None):
        """Create bar chart of gene distribution"""
        plots_data = results.get('plots', {})
        gene_data = plots_data.get('gene_distribution', {})
        
        if not gene_data:
            return None
        
        # Create bar chart
        genes = list(gene_data.keys())
        counts = list(gene_data.values())
        
        fig = go.Figure(data=[go.Bar(
            x=genes,
            y=counts,
            marker_color='#118AB2'
        )])
        
        fig.update_layout(
            title="Variants by Gene",
            xaxis_title="Gene",
            yaxis_title="Number of Variants"
        )
        
        if save_path:
            fig.write_html(save_path)
        
        return fig.to_dict()
    
    @staticmethod
    def create_variant_table(results: Dict) -> Dict:
        """Create formatted variant table data"""
        variants = results.get('variants', [])
        
        if not variants:
            return {"columns": [], "data": []}
        
        # Convert to DataFrame for easy manipulation
        df = pd.DataFrame(variants)
        
        # Select relevant columns
        display_columns = ['gene', 'chromosome', 'position', 'consequence', 
                         'clinvar_significance', 'risk_level']
        
        # Filter available columns
        available_cols = [col for col in display_columns if col in df.columns]
        df_display = df[available_cols]
        
        return {
            "columns": available_cols,
            "data": df_display.to_dict('records')
        }
    
    @staticmethod
    def create_summary_cards(results: Dict) -> List[Dict]:
        """Create summary cards for dashboard display"""
        cards = [
            {
                "title": "Overall Risk",
                "value": results.get('overall_risk', 'Unknown'),
                "color": "#FF6B6B" if "High" in str(results.get('overall_risk', '')) else "#06D6A0",
                "icon": "⚠️" if "High" in str(results.get('overall_risk', '')) else "✅"
            },
            {
                "title": "Variants Analyzed",
                "value": results.get('variant_count', 0),
                "color": "#118AB2",
                "icon": "🧬"
            },
            {
                "title": "Pathogenic Variants",
                "value": results.get('pathogenic_count', 0),
                "color": "#FF6B6B",
                "icon": "❗"
            },
            {
                "title": "VUS",
                "value": results.get('vus_count', 0),
                "color": "#FFD166",
                "icon": "❓"
            }
        ]
        
        return cards
    
    @staticmethod
    def generate_comprehensive_report(results: Dict, output_dir: str = "reports"):
        """Generate complete report with all visualizations"""
        Path(output_dir).mkdir(exist_ok=True)
        
        report_data = {
            "patient_info": {
                "patient_id": results.get('patient_id'),
                "analysis_date": results.get('analysis_date'),
                "overall_risk": results.get('overall_risk')
            },
            "summary_cards": ReportGenerator.create_summary_cards(results),
            "variant_table": ReportGenerator.create_variant_table(results),
            "visualizations": {
                "risk_distribution": ReportGenerator.create_risk_distribution_plot(
                    results, 
                    f"{output_dir}/risk_distribution.html"
                ),
                "gene_distribution": ReportGenerator.create_gene_distribution_chart(
                    results,
                    f"{output_dir}/gene_distribution.html"
                )
            },
            "recommendations": results.get('recommendations', []),
            "clinical_implications": results.get('summary', {}).get('clinical_implications', [])
        }
        
        # Save report data
        report_path = f"{output_dir}/report_data.json"
        with open(report_path, 'w') as f:
            json.dump(report_data, f, indent=2, default=str)
        
        print(f"Report generated at {report_path}")
        return report_data

if __name__ == "__main__":
    # Test report generation
    with open("analysis_results.json", "r") as f:
        results = json.load(f)
    
    report = ReportGenerator.generate_comprehensive_report(results)
    print("Report generation complete")